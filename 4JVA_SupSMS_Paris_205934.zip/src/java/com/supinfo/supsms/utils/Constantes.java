package com.supinfo.supsms.utils;

/**
 *
 * @author ___Cid___
 */
public class Constantes {
    
    public final static String SESSION_USER_ATTRIBUTE_NAME = "user";
    
    public final static String HOME_PATH = "/home";
    
}
